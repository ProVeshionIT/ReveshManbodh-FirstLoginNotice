<#
��� Show Notice Script
��� Version: 1.0.0
��� Author: Revesh Manbodh 
    Company: ProVeshion IT
��� Description: Notification script at first login.
#>

# === Step 1a: Get active session of user via explorer.exe===
$explorer = Get-Process explorer -ErrorAction SilentlyContinue | Select-Object -First 1
if ($explorer) {
    $user = (Get-WmiObject Win32_Process -Filter "ProcessId = $($explorer.Id)").GetOwner().User
    $userProfile = [System.Environment]::ExpandEnvironmentVariables("C:\Users\$user\AppData\Roaming")
    $markerFolder = Join-Path $userProfile "FirstLoginNoticeShown"
    $markerPath = Join-Path $markerFolder "Marker.txt"
} 

# === Step 1b: Stop! if markerfile already created===
if (Test-Path $markerPath) {
    return
}

# Load .NET types
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Create form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Bevestiging"
$form.Size = New-Object System.Drawing.Size(1450, 650)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false

# Banner
$pictureBox = New-Object System.Windows.Forms.PictureBox
$pictureBox.Size = New-Object System.Drawing.Size(1300, 140)
$pictureBox.Location = New-Object System.Drawing.Point(50, 20)
$pictureBox.SizeMode = "StretchImage"
$pictureBox.Image = [System.Drawing.Image]::FromFile("C:\FirstLoginNotice\Banner.jpg")

# Label
$label = New-Object System.Windows.Forms.Label
$label.Text = "Enter here what you want and with what information you want to inform the user."
$label.Font = New-Object System.Drawing.Font("Segoe UI", 16)
$label.Size = New-Object System.Drawing.Size(1300, 320)
$label.Location = New-Object System.Drawing.Point(50, 180)
$label.AutoSize = $false

# OK-button below the text, centered
$okButton = New-Object System.Windows.Forms.Button
$okButton.Text = "OK"
$okButton.Font = New-Object System.Drawing.Font("Segoe UI", 14)
$okButton.Size = New-Object System.Drawing.Size(140, 60)

# Center label
$okButtonX = $form.ClientSize.Width / 2 - $okButton.Width / 2
$okButtonY = $label.Location.Y + $label.Height + 10
$okButton.Location = New-Object System.Drawing.Point($okButtonX, $okButtonY)

$okButton.Add_Click({ $form.Close() })

# Add to form
$form.Controls.Add($pictureBox)
$form.Controls.Add($label)
$form.Controls.Add($okButton)

# Show form
$form.ShowDialog()



# Create markerfolder if not exist
if (-not (Test-Path $markerFolder)) {
    New-Item -ItemType Directory -Path $markerFolder -Force | Out-Null
}

# Place markerfile
New-Item -ItemType File -Path $markerPath -Force | Out-Null
