﻿<#
    First Login Notification Script
    Version: 1.0.0
    Author: Revesh Manbodh 
    Company: ProVeshion IT
    Description: Creation to displays a user-friendly notification at first login, even when ESP Account Setup is skipped.
#>


# === Config ===
$scriptPath = "C:\FirstLoginNotice"
$taskName = "FirstLoginNotice"
$serviceUI = "ServiceUI.exe"
$bannerFile = "Banner.jpg"
$scriptFile = "ShowNotice.ps1"

# === Step 1: Create Source directory===
if (-not (Test-Path $scriptPath)) {
    New-Item -Path $scriptPath -ItemType Directory | Out-Null
}

# === Step 2: Get dest directory===
$scriptPathRaw = $MyInvocation.MyCommand.Path
$scriptDir = if ([string]::IsNullOrWhiteSpace($scriptPathRaw)) { (Get-Location).Path } else { Split-Path -Parent $scriptPathRaw }

# === Step 3: Copy files===
$filesToCopy = @($bannerFile, $scriptFile, $serviceUI)

foreach ($file in $filesToCopy) {
    $source = Join-Path -Path $scriptDir -ChildPath $file
    $target = Join-Path -Path $scriptPath -ChildPath $file

    if (Test-Path $source) {
        Copy-Item -Path $source -Destination $target -Force
    }
}

# === Step 4: Create schedtask===
try {
    $taskProgram = Join-Path $scriptPath $serviceUI
    $taskArguments = "-process:explorer.exe C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -ExecutionPolicy Bypass -File `"$scriptPath\$scriptFile`""
    $fullCommand = "`"$taskProgram`" $taskArguments"

    schtasks.exe /Create /TN $taskName /TR $fullCommand /SC ONLOGON /RL HIGHEST /RU "SYSTEM" /F
    "Scheduled task successfully registered." | Out-File "$scriptPath\install-task.txt" -Append
} catch {
    "Failed to register scheduled task: $($_.Exception.Message)" | Out-File "$scriptPath\install-task.txt" -Append
}

# === Step 5: Change battery settings ===
try {
    $service = New-Object -ComObject "Schedule.Service"
    $service.Connect()
    $task = $service.GetFolder("\").GetTask($taskName)
    $definition = $task.Definition

    $definition.Settings.StopIfGoingOnBatteries = $false
    $definition.Settings.DisallowStartIfOnBatteries = $false

    $service.GetFolder("\").RegisterTaskDefinition($taskName, $definition, 6, $null, $null, 3, $null)
} catch {}
