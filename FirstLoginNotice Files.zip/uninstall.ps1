<#
��� Show Notice Script
��� Version: 1.0.0
��� Author: Revesh Manbodh 
    Company: ProVeshion IT
��� Description: Uninstall first login configuration.
#>

# Delete schedtask
try {
    Unregister-ScheduledTask -TaskName "FirstLoginNotice" -Confirm:$false -ErrorAction SilentlyContinue
} catch {
    Write-Output "Task not found."
}

# Delete files
$scriptPath = "C:\FirstLoginNotice"
if (Test-Path $scriptPath) {
    Remove-Item -Path $scriptPath -Recurse -Force
}
